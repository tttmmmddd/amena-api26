from sqlalchemy import (
    Column, String, SmallInteger, Numeric, Text, DateTime, ForeignKey, Enum as SAEnum
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from app.core.database import Base
from app.core.types import GUID, new_uuid
from app.models.enums import OrderStatus, EscrowStatus, PaymentMethod


class Order(Base):
    __tablename__ = "orders"

    id = Column(GUID(), primary_key=True, default=new_uuid)
    order_number = Column(String(20), nullable=False, unique=True, index=True)
    buyer_id = Column(GUID(), ForeignKey("users.id"), nullable=False, index=True)
    status = Column(SAEnum(OrderStatus), nullable=False, default=OrderStatus.pending_payment, index=True)

    subtotal_amount = Column(Numeric(12, 2), nullable=False)
    shipping_fee = Column(Numeric(12, 2), nullable=False, default=0)
    platform_commission = Column(Numeric(12, 2), nullable=False, default=0)
    total_amount = Column(Numeric(12, 2), nullable=False)

    delivery_wilaya_id = Column(SmallInteger, ForeignKey("wilayas.id"), nullable=False)
    delivery_address = Column(Text)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    delivered_at = Column(DateTime(timezone=True), nullable=True)

    items = relationship("OrderItem", back_populates="order", cascade="all, delete-orphan")
    escrow = relationship("EscrowTransaction", back_populates="order", uselist=False, cascade="all, delete-orphan")


class OrderItem(Base):
    __tablename__ = "order_items"

    id = Column(GUID(), primary_key=True, default=new_uuid)
    order_id = Column(GUID(), ForeignKey("orders.id", ondelete="CASCADE"), nullable=False, index=True)
    product_id = Column(GUID(), ForeignKey("products.id"), nullable=False)
    quantity = Column(Numeric(12, 2), nullable=False)
    unit_price = Column(Numeric(12, 2), nullable=False)

    order = relationship("Order", back_populates="items")

    @property
    def line_total(self):
        return self.quantity * self.unit_price


class EscrowTransaction(Base):
    __tablename__ = "escrow_transactions"

    id = Column(GUID(), primary_key=True, default=new_uuid)
    order_id = Column(GUID(), ForeignKey("orders.id", ondelete="CASCADE"), nullable=False, unique=True)
    amount = Column(Numeric(12, 2), nullable=False)
    payment_method = Column(SAEnum(PaymentMethod), nullable=False)
    status = Column(SAEnum(EscrowStatus), nullable=False, default=EscrowStatus.held, index=True)

    held_at = Column(DateTime(timezone=True), server_default=func.now())
    released_at = Column(DateTime(timezone=True), nullable=True)
    refunded_at = Column(DateTime(timezone=True), nullable=True)
    auto_release_at = Column(DateTime(timezone=True), nullable=True)

    dispute_reason = Column(Text, nullable=True)
    dispute_opened_at = Column(DateTime(timezone=True), nullable=True)
    dispute_resolved_by = Column(GUID(), ForeignKey("users.id"), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    order = relationship("Order", back_populates="escrow")


class WalletLedgerEntry(Base):
    __tablename__ = "wallet_ledger_entries"

    id = Column(GUID(), primary_key=True, default=new_uuid)
    user_id = Column(GUID(), ForeignKey("users.id"), nullable=False, index=True)
    entry_type = Column(String(30), nullable=False)
    amount = Column(Numeric(12, 2), nullable=False)
    related_order_id = Column(GUID(), ForeignKey("orders.id"), nullable=True)
    description = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
