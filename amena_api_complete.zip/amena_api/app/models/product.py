from sqlalchemy import (
    Column, String, Integer, SmallInteger, Numeric, Boolean, Text, DateTime, ForeignKey, Enum as SAEnum
)
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from app.core.database import Base
from app.core.types import GUID, new_uuid
from app.models.enums import ProductCategory, ProductUnit


class Product(Base):
    __tablename__ = "products"

    id = Column(GUID(), primary_key=True, default=new_uuid)
    farmer_id = Column(GUID(), ForeignKey("farmer_profiles.user_id", ondelete="CASCADE"), nullable=False, index=True)
    category = Column(SAEnum(ProductCategory), nullable=False, index=True)
    name = Column(String(200), nullable=False)
    description = Column(Text)
    price = Column(Numeric(12, 2), nullable=False)
    unit = Column(SAEnum(ProductUnit), nullable=False)
    quantity_available = Column(Numeric(12, 2), nullable=False, default=0)
    min_order_quantity = Column(Numeric(12, 2), default=1)

    wilaya_id = Column(SmallInteger, ForeignKey("wilayas.id"), nullable=False, index=True)
    pickup_address = Column(Text)

    qr_tracked = Column(Boolean, nullable=False, default=False)
    qr_code_value = Column(Text, unique=True, nullable=True)

    is_for_rent = Column(Boolean, nullable=False, default=False)
    is_wholesale_only = Column(Boolean, nullable=False, default=False)

    is_active = Column(Boolean, nullable=False, default=True, index=True)
    views_count = Column(Integer, nullable=False, default=0)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    farmer = relationship("FarmerProfile", back_populates="products")
    images = relationship("ProductImage", back_populates="product", cascade="all, delete-orphan")


class ProductImage(Base):
    __tablename__ = "product_images"

    id = Column(GUID(), primary_key=True, default=new_uuid)
    product_id = Column(GUID(), ForeignKey("products.id", ondelete="CASCADE"), nullable=False)
    image_url = Column(Text, nullable=False)
    sort_order = Column(SmallInteger, nullable=False, default=0)

    product = relationship("Product", back_populates="images")
