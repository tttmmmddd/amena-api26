"""
استيراد كل النماذج هنا يضمن أن SQLAlchemy يستطيع حلّ كل العلاقات (relationships)
بين الجداول عند استدعاء Base.metadata.create_all()
"""
from app.models.wilaya import Wilaya
from app.models.user import User
from app.models.profiles import FarmerProfile, TraderProfile, TransporterProfile, ExpertProfile
from app.models.product import Product, ProductImage
from app.models.order import Order, OrderItem, EscrowTransaction, WalletLedgerEntry

__all__ = [
    "Wilaya",
    "User",
    "FarmerProfile",
    "TraderProfile",
    "TransporterProfile",
    "ExpertProfile",
    "Product",
    "ProductImage",
    "Order",
    "OrderItem",
    "EscrowTransaction",
    "WalletLedgerEntry",
]
