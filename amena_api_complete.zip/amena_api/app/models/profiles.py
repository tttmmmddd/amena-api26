from sqlalchemy import (
    Column, String, Integer, SmallInteger, Numeric, Boolean, Text, Date, ForeignKey, Enum as SAEnum
)
from sqlalchemy.orm import relationship

from app.core.database import Base
from app.core.types import GUID
from app.models.enums import PaymentMethod


class FarmerProfile(Base):
    __tablename__ = "farmer_profiles"

    user_id = Column(GUID(), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    farm_name = Column(String(150), nullable=False)
    farm_description = Column(Text)
    established_year = Column(SmallInteger)
    total_area_hectares = Column(Numeric(10, 2))
    verified_badge = Column(Boolean, nullable=False, default=False)
    rating = Column(Numeric(2, 1), default=0.0)
    rating_count = Column(Integer, nullable=False, default=0)
    bank_account_iban = Column(String(34))
    withdrawal_method = Column(SAEnum(PaymentMethod), default=PaymentMethod.ccp)

    user = relationship("User", back_populates="farmer_profile")
    products = relationship("Product", back_populates="farmer")


class TraderProfile(Base):
    __tablename__ = "trader_profiles"

    user_id = Column(GUID(), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    business_name = Column(String(150), nullable=False)
    trade_register_no = Column(String(50), unique=True)
    tax_id = Column(String(50))
    business_type = Column(String(50))
    monthly_volume_estimate = Column(Numeric(12, 2))

    user = relationship("User", back_populates="trader_profile")


class TransporterProfile(Base):
    __tablename__ = "transporter_profiles"

    user_id = Column(GUID(), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    vehicle_type = Column(String(50), nullable=False)
    plate_number = Column(String(20), nullable=False)
    vehicle_year = Column(SmallInteger)
    capacity_kg = Column(Numeric(10, 2))
    insurance_valid_until = Column(Date)
    transport_license_url = Column(Text)
    rating = Column(Numeric(2, 1), default=0.0)
    rating_count = Column(Integer, nullable=False, default=0)
    is_available = Column(Boolean, nullable=False, default=True)
    current_wilaya_id = Column(SmallInteger, ForeignKey("wilayas.id"))

    user = relationship("User", back_populates="transporter_profile")


class ExpertProfile(Base):
    __tablename__ = "expert_profiles"

    user_id = Column(GUID(), ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    specialty = Column(String(150), nullable=False)
    years_experience = Column(SmallInteger)
    academic_credentials = Column(Text)
    license_number = Column(String(50))
    rating = Column(Numeric(2, 1), default=0.0)
    rating_count = Column(Integer, nullable=False, default=0)
    consultation_fee = Column(Numeric(10, 2))
    inspection_fee = Column(Numeric(10, 2))

    user = relationship("User", back_populates="expert_profile")
