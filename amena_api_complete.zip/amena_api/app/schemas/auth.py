"""
Pydantic schemas لتسجيل الدخول، إنشاء الحساب، والمصادقة الثنائية
"""
import uuid
from typing import Optional

from pydantic import BaseModel, EmailStr, Field, field_validator

from app.models.enums import UserRole, KycStatus


class UserRegisterRequest(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=150)
    phone: str = Field(..., min_length=8, max_length=20)
    email: Optional[EmailStr] = None
    password: str = Field(..., min_length=8, max_length=72)
    primary_role: UserRole
    wilaya_id: int = Field(..., ge=1, le=69)

    @field_validator("phone")
    @classmethod
    def phone_must_be_algerian_format(cls, v: str) -> str:
        cleaned = v.replace(" ", "").replace("-", "")
        if not cleaned.startswith(("+213", "0")):
            raise ValueError("رقم الهاتف يجب أن يبدأ بـ +213 أو 0")
        return v


class UserLoginRequest(BaseModel):
    phone: str
    password: str
    totp_code: Optional[str] = Field(None, min_length=6, max_length=6, description="مطلوب إذا كانت 2FA مفعّلة")


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    requires_2fa: bool = False


class RefreshTokenRequest(BaseModel):
    refresh_token: str


class Enable2FAResponse(BaseModel):
    secret: str
    provisioning_uri: str
    message: str = "امسح رمز QR في تطبيق المصادقة ثم أكّد بإرسال الرمز إلى /auth/2fa/confirm"


class Confirm2FARequest(BaseModel):
    totp_code: str = Field(..., min_length=6, max_length=6)


class UserOut(BaseModel):
    id: uuid.UUID
    full_name: str
    phone: str
    email: Optional[str] = None
    primary_role: UserRole
    wilaya_id: int
    kyc_status: KycStatus
    two_fa_enabled: bool
    loyalty_points: int
    loyalty_tier: Optional[str] = None

    model_config = {"from_attributes": True}
