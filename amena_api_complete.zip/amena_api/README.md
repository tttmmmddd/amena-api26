# AMENA API — الواجهة البرمجية الخلفية

طبقة FastAPI كاملة فوق مخطط قاعدة بيانات آمنة، تغطي: المصادقة (تسجيل/دخول/2FA)، الملفات الشخصية حسب الدور، المنتجات، الطلبات، والدفع الآمن Escrow.

## التشغيل المحلي (تطوير سريع بـ SQLite)

```bash
pip install -r requirements.txt

# تعبئة الولايات الـ69
python -m app.seed

# تشغيل الخادم
uvicorn app.main:app --reload
```

افتح `http://127.0.0.1:8000/docs` لواجهة Swagger التفاعلية الكاملة.

## التشغيل مع PostgreSQL (للإنتاج)

```bash
cp .env.example .env
# عدّل DATABASE_URL في .env إلى رابط PostgreSQL الحقيقي
export $(cat .env | xargs)

# نفّذ ملفات SQL الأصلية أولاً (من مجلد amena_database/) لإنشاء المخطط:
psql -d amena_db -f ../amena_database/schema.sql
psql -d amena_db -f ../amena_database/seed_wilayas.sql

# أو دع SQLAlchemy ينشئ الجداول تلقائياً (للتطوير فقط، وليس الإنتاج):
uvicorn app.main:app
```

⚠️ **ملاحظة مهمة**: في الإنتاج الحقيقي، استخدم Alembic لإدارة الترحيلات (migrations) بدل `Base.metadata.create_all()`، ونفّذ `schema.sql` يدوياً كمصدر الحقيقة الوحيد لبنية القاعدة.

## بنية المشروع

```
app/
├── core/
│   ├── config.py      # إعدادات (متغيرات البيئة)
│   ├── database.py    # اتصال SQLAlchemy + جلسات
│   ├── security.py    # bcrypt، JWT، TOTP (2FA)
│   ├── deps.py         # Dependencies للمصادقة وحصر الأدوار
│   └── types.py         # نوع UUID متوافق مع SQLite وPostgreSQL
├── models/              # SQLAlchemy ORM models (تطابق schema.sql)
├── schemas/              # Pydantic request/response schemas
├── routers/
│   ├── auth.py            # /auth — تسجيل، دخول، 2FA
│   ├── profiles.py         # /profiles — ملفات الأدوار (مزارع، تاجر...)
│   ├── products.py          # /products — CRUD + فلترة
│   └── orders.py             # /orders + /escrow — الشراء والدفع الآمن
├── seed.py                    # تعبئة الولايات الـ69 (للتطوير المحلي)
└── main.py                     # نقطة الدخول
```

## الـ Endpoints المتاحة (21 endpoint)

### المصادقة `/api/v1/auth`
| الطريقة | المسار | الوصف |
|---|---|---|
| POST | `/register` | تسجيل حساب جديد (أي دور) |
| POST | `/login` | دخول — يُرجع JWT أو يطلب رمز 2FA |
| POST | `/refresh` | تجديد access token |
| GET | `/me` | بيانات المستخدم الحالي |
| POST | `/2fa/enable` | بدء تفعيل المصادقة الثنائية (يُرجع QR secret) |
| POST | `/2fa/confirm` | تأكيد التفعيل برمز TOTP |
| POST | `/2fa/disable` | إلغاء التفعيل |

### الملفات الشخصية `/api/v1/profiles`
| الطريقة | المسار | الوصف |
|---|---|---|
| POST | `/farmer` | إنشاء ملف مزارع |
| POST | `/trader` | إنشاء ملف تاجر |
| POST | `/transporter` | إنشاء ملف ناقل |
| POST | `/expert` | إنشاء ملف خبير |

### المنتجات `/api/v1/products`
| الطريقة | المسار | الوصف |
|---|---|---|
| GET | `/` | قائمة + فلترة (category, wilaya_id, is_for_rent, search) |
| POST | `/` | إضافة منتج (مزارع فقط) |
| GET | `/{id}` | تفاصيل منتج |
| PATCH | `/{id}` | تعديل (المالك فقط) |
| DELETE | `/{id}` | حذف (المالك فقط) |

### الطلبات والدفع الآمن `/api/v1/orders` و `/api/v1/escrow`
| الطريقة | المسار | الوصف |
|---|---|---|
| POST | `/orders` | إنشاء طلب (يحجز الكمية فوراً) |
| GET | `/orders` | طلباتي |
| GET | `/orders/{id}` | تفاصيل طلب |
| POST | `/escrow/orders/{id}/pay` | دفع وتجميد المبلغ |
| GET | `/escrow/orders/{id}` | حالة Escrow |
| POST | `/escrow/orders/{id}/release` | تحرير المبلغ بعد تأكيد الاستلام |
| POST | `/escrow/orders/{id}/dispute` | فتح نزاع |

## قرارات تصميم مهمة

- **حجز المخزون الفوري**: عند إنشاء الطلب (وليس عند الدفع)، تُخصَم الكمية من `quantity_available` مباشرة لمنع البيع المضاعف (oversell) في حال تزامن طلبين على نفس المنتج.
- **عمولة المنصة تُحسب تلقائياً**: من `platform_settings` (افتراضياً 2%)، وتُخصم من المزارع عند التحرير وليس من المشتري.
- **Escrow منفصل عن Order**: يسمح بتتبع دقيق لحالة الأموال (محجوزة/محرَّرة/متنازع عليها) بمعزل عن حالة الشحن.
- **`auto_release_at`**: محسوبة عند الدفع (افتراضياً بعد 48 ساعة) — تحتاج Cron Job أو Celery Beat في الإنتاج لتنفيذ التحرير التلقائي فعلياً (غير مبني هنا بعد).
- **التحقق من الولاية**: كل endpoint يستقبل `wilaya_id` يتحقق من أنه بين 1 و69 على مستوى Pydantic (validation أولي)، ثم من وجوده الفعلي في جدول `wilayas` على مستوى منطق العمل.

## الاختبار

ملف `test_e2e.sh` يغطي 15 سيناريو كامل (تسجيل → منتج → طلب → دفع → تحرير → حالات فشل متوقعة) وقد نجح بالكامل دون أخطاء.

```bash
uvicorn app.main:app &
bash test_e2e.sh
```

## الخطوات التالية المقترحة

1. **Alembic** لإدارة ترحيلات قاعدة البيانات بدل `create_all()`.
2. **Endpoints الشحن** (`/shipments`) وربطها بـ `transporter_profiles`.
3. **Endpoints شهادات الجودة** (`/quality-certificates`) للخبراء.
4. **Endpoints البث المباشر والمزادات** (`/auctions`, `/bids`) — تحتاج WebSocket للتحديث الحي.
5. **Background job** (Celery أو APScheduler) لتنفيذ `auto_release_at` فعلياً.
6. **رفع الملفات** (صور المنتجات، وثائق KYC) عبر S3-compatible storage.
7. **بوابات دفع حقيقية**: ربط فعلي بـ CIB/BaridiMob/CCP بدل المحاكاة الحالية.
8. **Rate limiting** و **اختبارات تكامل أعمق** (pytest) قبل الإنتاج.
